from pygame import *
from PyGameGame import PygameGame
import math
import random
from Characters import Character
from Characters import Enemy
from Characters import Shooter
from Start import StartScreen
from Start import Selection
from Start import EndLevel
import string

# from Characters import Enemy
#PygameGame framework created by Lukas Peraza

class Bullet(sprite.Sprite):
    #defines a bullet
    def __init__(self, x, y, angle, color):
        self.image = image.load(color)
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.angle = angle
        self.rect.x = x
        self.rect.y = y
        self.velocity = 11
        sprite.Sprite.__init__(self)
        
    def move(self):
        self.rect.x += math.cos(math.radians(self.angle))*self.velocity
        self.rect.y += math.sin(math.radians(self.angle))*self.velocity
    
    def check(self, width, height):
        #returns True if bullet off the screen
        if self.rect.x + 10 > width or self.rect.x - 10 < 0 or self.rect.y - 10 < 0 or self.rect.y > height:
            return True
        return False
        
class EnBullet(sprite.Sprite):
    def __init__(self,x,y,color,scrollX,scrollY,cx,cy):
        self.image = image.load(color)
        self.image = transform.scale(self.image, (20,20))
        self.rect = self.image.get_rect()
        self.cx = cx
        self.cy = cy
        self.x = x
        self.y = y
        self.velocity = 11
        # self.theta = math.tan(math.radians((self.cy-self.y)/(self.cx-self.x)))
        # self.changeX = math.cos(math.radians(self.theta))*self.velocity
        # self.changeY = math.sin(math.radians(self.theta))*self.velocity
        # print(self.changeX,self.changeY)
        sprite.Sprite.__init__(self)

    def correct(self, scrollX, scrollY):
        self.rect.x = self.x - scrollX
        self.rect.y = self.y - scrollY

    # def move(self):
    #     if self.x in range(int(self.cx-5),int(self.cx+5)):
    #         self.y += self.velocity
    #     if self.x not in range(int(self.cx-5),int(self.cx+5)):
    #         if self.x < self.cx -5:
    #             self.x -= self.velocity
    #         if self.x > self.cx +5:
    #             self.x += self.velocity
    #     if self.y in range(int(self.cy-5),int(self.cy+5)):
    #         self.x -= self.velocity
    #     if self.y in range(int(self.cy-5),int(self.cy+5)):
    #         if self.y < self.cy-5:
    #             self.y -= self.velocity
    #         if self.y > self.cy+5:
    #             self.y += self.velocity
    def move(self, charX, charY):
        if charX < self.rect.x:
            self.x -= 5
        if charX > self.rect.x:
            self.x += 5
        if charY > self.rect.y:
            self.y += 5
        if charY < self.rect.y:
            self.y -= 5

class Flag(sprite.Sprite):
    def __init__(self,x,y):
        self.image = image.load("flag.png")
        #http://alexinthestudio.blogspot.com/2016/03/summative-one-unity-prototype.html for flag image
        self.image = transform.scale(self.image,(60,60))
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        sprite.Sprite.__init__(self)

    def draw(self, screen, scrollX, scrollY):
        self.rect.x = self.x - scrollX
        self.rect.y = self.y - scrollY
        screen.blit(self.image,(self.rect.x, self.rect.y))

class DirectionArrow(sprite.Sprite):
    #shows direction that character faces
    def __init__(self, distance, x, y):
        self.distance = distance
        self.image = image.load("arrow.jpg")
        #http://icons.mysitemyway.com/legacy-icon/004035-grunge-brushed-metal-pewter-icon-arrows-arrowhead-solid-left/ for arrow image
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.angle = 0
        self.distance = 10
        sprite.Sprite.__init__(self)

    def move(self, keyCode):
        if keyCode == 113:
            self.angle -= self.distance
            self.rect.x += math.cos(math.radians(self.angle))*self.distance
            self.rect.y += math.sin(math.radians(self.angle))*self.distance
        if keyCode == 101:
            self.angle += self.distance
            self.rect.x += math.cos(math.radians(self.angle))*self.distance
            self.rect.y += math.sin(math.radians(self.angle))*self.distance
        #move char and rotate the direction it faces
        if keyCode == 100:
            self.angle = 0
        if keyCode == 97:
            self.angle = 180
        if keyCode == 119:
            self.angle = 270
        if keyCode == 115:
            self.angle = 90
        #quick select a direction
        self.rect.x += math.cos(math.radians(self.angle))*self.distance
        self.rect.y += math.sin(math.radians(self.angle))*self.distance
        

class Game(PygameGame):
    #holds the entire game structure
    def init(self):
        self.bigHeight = self.width*10
        self.bigWidth = self.height*10
        self.scrollX = self.bigWidth/2-self.width/2
        self.scrollY = self.bigHeight/2-self.height/2
        self.gameMode = "Start"
        self.choice = 2
        #character selection
        self.characters = [("A&W.png", "orangeBolt.png", "pepsiCan.png", "7upCan.png", (153,76,0), "A&WCan.png","blue.jpg","leaves.jpg"),("Pepsiman.png", "blueBolt.png", "7upCan.png", "A&WCan.png", (0,0,255),"PepsiCan.png", "leaves.jpg","dirt.jpg"), ("Spot.png", "redBolt.png", "A&WCan.png","pepsiCan.png", (244,98,65),"7upCan.png","dirt.jpg","blue.jpg")]
        #https://gamebanana.com/requests/3908 for the pepsiman sprite
        #http://coolspot.wikia.com/wiki/Spot_(Character) for cool spot image
        #https://www.pinterest.com/pin/312366924137428328/ for rooty image
        #https://www.vectorstock.com/royalty-free-vector/fire-sprite-sheet-cartoon-flame-game-vector-15143660 for fireballs
        #https://www.pinterest.com/pin/369787819385381471/ for blue and red fireballs
        #http://bbqpontoon.com/product/pepsi-can for pepsi can image
        #https://www.walmart.com/ip/A-W-Root-Beer-12-fl-oz-12-pack/10448431 for A&W can image
        #https://www.7up.com/en for 7up can image
        self.char = Character(10, 1, 10, 30,self.characters[self.choice][0],self.width/2,self.height/2)
        #init character and direction arrow
        self.arrow = DirectionArrow(10, self.char.rect.x, self.char.rect.y)
        #position of direction arrow
        self.canGroup1 = sprite.Group()
        self.canGroup2 = sprite.Group()
        #all the enemy cans
        self.charGroup = sprite.Group()
        self.bulletGroup = sprite.Group()
        self.arrowGroup = sprite.Group(self.arrow)
        #creates sprite groups
        self.timer = 0
        #saves time
        self.flagFind = 0
        #number of flags you found
        self.flagX1 = random.randint(100,self.bigWidth/2-100)
        self.flagY1 = random.randint(100,self.bigHeight-100)
        self.flagX2 = random.randint(self.bigWidth/2-100, self.bigWidth-100)
        self.flagY2 = random.randint(100,self.bigHeight-100)
        #sets both flag positions
        self.flag1 = Flag(self.flagX1,self.flagY1)
        self.flag2 = Flag(self.flagX2, self.flagY2)
        self.flagGroup = (self.flag1,self.flag2)
        self.flag1found = False
        self.flag2found = False
        #flag locations and drawings
        self.level = 1
        #level number
        self.name = ""
        #name of player after win
        self.egg = False
        #extra thingy
        self.enBulletGroup = sprite.Group()
        self.shooterGroup1 = sprite.Group()
        self.shooterGroup2 = sprite.Group()
        #group for enemy bullets and shooters
        
    def keyPressed(self, keyCode, modifier):
        if self.gameMode == "Start":
            if keyCode == 112:
                self.gameMode = "Select"
        if self.gameMode == "End":
            if keyCode == 304:
                self.gameMode = "Play"
                self.char = Character(10+(self.level*1),1+(self.level%2*1),10,30+((self.level-1)*10),self.characters[self.choice][0],self.width/2,self.height/2)
                self.scrollX = self.bigWidth/2-self.width/2
                self.scrollY = self.bigHeight/2-self.height/2
                self.flagX1 = random.randint(0,self.bigWidth/2)
                self.flagY1 = random.randint(0,self.bigHeight)
                self.flagX2 = random.randint(self.bigWidth/2, self.bigWidth)
                self.flagY2 = random.randint(0,self.bigHeight)
                #sets both flag positions
                self.flag1 = Flag(self.flagX1,self.flagY1)
                self.flag2 = Flag(self.flagX2, self.flagY2)
                self.flagGroup = (self.flag1,self.flag2)
                self.flagFind = 0
                self.flag1found = False
                self.flag2found = False
                sprite.Group.empty(self.canGroup1)
                sprite.Group.empty(self.canGroup2)
                sprite.Group.empty(self.bulletGroup)
                sprite.Group.empty(self.enBulletGroup)
                sprite.Group.empty(self.shooterGroup1)
                sprite.Group.empty(self.shooterGroup2)
            #resets after level ends
        if self.gameMode == "Play":
            self.arrow.move(keyCode)
            if keyCode == 275:
                if self.scrollX + 20 < 4690:
                    self.scrollX += (20)
            if keyCode == 276:
                if self.scrollX - 20 > -190:
                    self.scrollX += (-20)
            if keyCode == 273:
                if self.scrollY - 20 > -230:
                    self.scrollY += (-20)
            if keyCode == 274:
                if self.scrollY + 20 < 4650:
                    self.scrollY += (20)
            #move char
            if keyCode == 32:
                if self.char.ammo > 0:
                    self.bulletGroup.add(Bullet(self.char.rect.x+50,self.char.rect.y+50,self.arrow.angle, self.characters[self.choice][1]))
                    self.char.ammo -= 1
        if self.gameMode == "Final":
            caps = False
            print(keyCode)
            if len(self.name) < 4:
                if chr(keyCode) in string.ascii_letters or keyCode == 32:
                        self.name += chr(keyCode)
            if keyCode == 8:
                self.name = self.name[:len(self.name)-1]
            if keyCode == 304:
                self.gameMode = "Win"
        if self.gameMode == "Win":
            if keyCode == 120 and self.egg:
                self.gameMode = "Trophy"
                
    def mousePressed(self, x, y):
        #character selection
        # print(self.egg)
        print(self.scrollX,self.scrollY)
        if self.gameMode == "Select":
            if y in range(int(self.height/3-40), int(self.height/3+60)):
                if x in range(20,150):
                    self.choice = 1
                    self.gameMode = "Play"
                if x in range(int(self.width/3+20),int(self.width/3+150)):
                    self.choice = 0
                    self.gameMode = "Play"
                if x in range(int(self.width/3*2+20),int(self.width/3*2+150)):
                    self.choice = 2
                    self.gameMode = "Play"
                self.char = Character(10, 1, 10, 30, self.characters[self.choice][0],self.width/2,self.height/2)
                self.charGroup.add(self.char)
        
    def timerFired(self, dt):
        #works with everything in the play screen
        if self.gameMode == "Play":
            # print(self.flagFind)
            # print(self.flag1.rect.x - self.char.rect.x, self.flag1.rect.y-self.char.rect.y, "flag1")
            # print(self.flag2.rect.x - self.char.rect.x, self.flag2.rect.y -self.char.rect.y, "flag2")
            if self.char.health == 0:
                self.gameMode = "Lose"
            self.timer += 1
            if self.timer %2 == 0:
                for bullet in self.bulletGroup:
                    bullet.move()
            if self.timer % 40 == 0:
                if self.flag1found == False:
                    self.canGroup1.add(Enemy(2,1*self.level,self.characters[self.choice][2], random.randint(0,self.bigWidth/2), random.randint(0,self.bigHeight)))
                if self.flag2found == False:
                    self.canGroup2.add(Enemy(2,1*self.level,self.characters[self.choice][3], random.randint(self.bigWidth/2,self.bigWidth), random.randint(0,self.bigHeight)))
            if abs(self.flag1.rect.x -self.char.rect.x) <= 60 and abs(self.flag1.rect.y - self.char.rect.y) <= 60 and not self.flag1found:
                for obj in self.canGroup1:
                    obj.can = self.characters[self.choice][5]
                self.flag1found = True
                self.flagFind += 1
            if abs(self.flag2.rect.x - self.char.rect.x) <= 60 and abs(self.flag2.rect.y -self.char.rect.y) <= 60 and not self.flag2found:
                for obj in self.canGroup2:
                    obj.can = self.characters[self.choice][5]
                self.flag2found = True
                self.flagFind += 1
            if self.flagFind == 2:
                self.level += 1
                self.gameMode = "End"
            if self.level == 3:
                self.gameMode = "Final"
            if self.timer%5 == 0:
                for can in self.canGroup1:
                    can.move(self.char.rect.x, self.char.rect.y)
                for can in self.canGroup2:
                    can.move(self.char.rect.x, self.char.rect.y)
                for bullet in self.enBulletGroup:
                    bullet.move(self.char.rect.x,self.char.rect.y)
                for can in self.shooterGroup1:
                    can.move(self.char.rect.x, self.char.rect.y)
                for can in self.shooterGroup2:
                    can.move(self.char.rect.x, self.char.rect.y)
            if self.timer%80 == 0:
                if self.flag1found == False:
                    self.shooterGroup1.add(Shooter(2,1,self.characters[self.choice][2], random.randint(0,self.bigWidth/2),random.randint(0,self.bigHeight)))
                if self.flag2found == False:
                    self.shooterGroup2.add(Shooter(2,1,self.characters[self.choice][3],random.randint(self.bigWidth/2,self.bigWidth),random.randint(0,self.bigHeight)))
            #spawn enemy bullets and cans
            if self.timer%100 == 0:
                if self.choice == 0:
                    if self.flag1found == False:
                        for en in self.shooterGroup1:
                            self.enBulletGroup.add(EnBullet(en.x,en.y,self.characters[1][1],self.scrollX,self.scrollY, self.char.rect.x-self.scrollX, self.char.rect.y-self.scrollY))
                    if self.flag2found == False:
                        for en in self.shooterGroup2:
                            self.enBulletGroup.add(EnBullet(en.x,en.y,self.characters[2][1],self.scrollX,self.scrollY, self.char.rect.x - self.scrollX, self.char.rect.y-self.scrollY))
                if self.choice == 1:
                    if self.flag1found == False:
                        for en in self.shooterGroup1:
                            self.enBulletGroup.add(EnBullet(en.x,en.y,self.characters[2][1],self.scrollX,self.scrollY, self.char.rect.x - self.scrollX, self.char.rect.y-self.scrollY))
                    if self.flag2found == False:
                        for en in self.shooterGroup2:
                            self.enBulletGroup.add(EnBullet(en.x,en.y,self.characters[0][1],self.scrollX,self.scrollY, self.char.rect.x - self.scrollX, self.char.rect.y-self.scrollY))
                if self.choice == 2:
                    if self.flag1found == False:
                        for en in self.shooterGroup1:
                            self.enBulletGroup.add(EnBullet(en.x,en.y,self.characters[0][1],self.scrollX,self.scrollY, self.char.rect.x - self.scrollX, self.char.rect.y-self.scrollY))
                    if self.flag2found == False:
                        for en in self.shooterGroup2:
                            self.enBulletGroup.add(EnBullet(en.x,en.y,self.characters[1][1],self.scrollX,self.scrollY, self.char.rect.x - self.scrollX, self.char.rect.y-self.scrollY))
            #shoot bullets for each shooter can
            for bullet in self.bulletGroup:
                if sprite.spritecollide(bullet, self.canGroup1, True):
                    self.bulletGroup.remove(bullet)
                if sprite.spritecollide(bullet, self.canGroup2, True):
                    self.bulletGroup.remove(bullet)
                if sprite.spritecollide(bullet, self.enBulletGroup,True):
                    self.bulletGroup.remove(bullet)
                if sprite.spritecollide(bullet,self.shooterGroup1,True):
                    self.bulletGroup.remove(bullet)
                if sprite.spritecollide(bullet, self.shooterGroup2,True):
                    self.bulletGroup.remove(bullet)
            if sprite.spritecollide(self.char, self.enBulletGroup,True):
                self.char.health -= 1
            if sprite.spritecollide(self.char,self.canGroup1, True):
                ouch = random.randint(0,20)
                if ouch == 3:
                    self.char.health -= 1
                elif self.flag1found:
                    self.char.health += 1
                else:
                    self.char.health -= 1*self.level
            if sprite.spritecollide(self.char,self.canGroup2,True):
                ouch = random.randint(0,20)
                if ouch == 3:
                    self.char.health -= 1
                elif self.flag2found:
                    self.char.health += 1
                else:
                    self.char.health -= 1*self.level
            if sprite.spritecollide(self.char,self.shooterGroup1,True):
                ouch = random.randint(0,30)
                if ouch == 3:
                    self.char.health -= 1
                elif self.flag1found:
                    self.char.ammo += 10
                else:
                    self.char.health -= 1*self.level
            if sprite.spritecollide(self.char,self.shooterGroup2,True):
                ouch = random.randint(0,30)
                if ouch == 3:
                    self.char.health -= 1
                elif self.flag2found:
                    self.char.ammo += 10
                else:
                    self.char.health -= 1*self.level
            #collisions
            if self.scrollX == -200 and self.scrollY == -250:
                self.egg = True
                
    def redrawAll(self, screen):
        #different game screens
        if self.gameMode == "Start":
            StartScreen(self.width, self.height).draw(screen)
            
        if self.gameMode == "Select":
            Selection(self.width,self.height).draw(screen)
            
        if self.gameMode == "End":
            EndLevel(self.width, self.height).draw(screen,self.characters[self.choice][0])
            
        if self.gameMode == "Play":
            draw.polygon(screen, (0,0,0), ((0-self.scrollX,0-self.scrollY),(self.bigWidth-self.scrollX,0-self.scrollY),(self.bigWidth-self.scrollX,self.bigHeight-self.scrollY),(0-self.scrollX,self.bigHeight-self.scrollY)),5)
            if self.choice == 0:
                color1 = 1
                color2 = 2
            if self.choice == 1:
                color1 = 2
                color2 = 0
            if self.choice == 2:
                color1 = 0
                color2 = 1
            side1 = image.load(self.characters[self.choice][6])
            side1 = transform.scale(side1, (int(self.bigWidth/2),self.bigHeight))
            side2 = image.load(self.characters[self.choice][7])
            side2 = transform.scale(side2, (int(self.bigWidth/2),self.bigHeight))
            screen.blit(side1,(0-self.scrollX,0-self.scrollY))
            screen.blit(side2,(int(self.bigWidth/2)-self.scrollX,0-self.scrollY))
            #https://hbr.org/2004/10/blue-ocean-strategy for blue background
            #http://www.rgbstock.com/photo/mgO6yrm/Red+leaves for leaf background
            #http://texturelib.com/texture/?path=/Textures/soil/rough%20ground/soil_rough_ground_0052 for dirt background
            #draw board
            self.flag1.draw(screen,self.scrollX, self.scrollY)
            self.flag2.draw(screen,self.scrollX, self.scrollY)
            #draw final flags
            self.charGroup.draw(screen)
            # self.arrowGroup.draw(screen)
            for can in self.canGroup1:
                can.change(self.scrollX, self.scrollY)
            for can in self.canGroup2:
                can.change(self.scrollX, self.scrollY)
            for can in self.shooterGroup1:
                can.change(self.scrollX, self.scrollY)
            for can in self.shooterGroup2:
                can.change(self.scrollX, self.scrollY)
            for bullet in self.enBulletGroup:
                bullet.correct(self.scrollX, self.scrollY)
            if len(self.bulletGroup) > 0:
                self.bulletGroup.draw(screen)
            if len(self.canGroup1) > 0 and len(self.canGroup2) > 0:
                self.canGroup1.draw(screen)
                self.canGroup2.draw(screen)
            if len(self.shooterGroup1) > 0:
                self.shooterGroup1.draw(screen)
            if len(self.shooterGroup2) > 0:
                self.shooterGroup2.draw(screen)
            if len(self.enBulletGroup) > 0:
                self.enBulletGroup.draw(screen)
            #draws every bullet and can
            for i in range(1,self.char.health+1):
                heart = image.load("heart.png")
                #https://twitter.com/heart for heart image
                heart = transform.scale(heart, (20,20))
                screen.blit(heart, (20*i,20))
            #draw hearts
            fonty = font.SysFont("Comic Sans",30,False,False)
            ammo = fonty.render("Ammo " + str(self.char.ammo),1, (0,255,0))
            screen.blit(ammo,(400,20))
        #playing the game
        if self.gameMode == "Final":
            fonty = font.SysFont("Comic Sans",40,False,False)
            title = fonty.render("Enter your name",1, (0,0,0))
            screen.blit(title,(self.width/3-30,self.height/3+30))
            middle = fonty.render("To claim the soda industry",1,(0,0,0))
            screen.blit(middle, (self.width/4-50, self.height/3*2))
            bottom = fonty.render("Press shift",1,(0,0,0))
            screen.blit(bottom, (self.width/3,self.height/4*3))
            draw.polygon(screen, (200,200,200), ((self.width/2-120,self.height/2-15),(self.width/2 + 120, self.height/2-15),(self.width/2+120, self.height/2+15),(self.width/2-120, self.height/2+15),5))
            myFont = font.SysFont("Comic Sans",35,True, False)
            name = myFont.render(self.name, 1, (0,0,0))
            screen.blit(name, (self.width/2-105,self.height/2-15))
        #put your name
        if self.gameMode == "Win":
            trophy =  image.load("trophy.png")
            #https://www.iconfinder.com/icons/257805/achievement_award_best_gold_prize_trophy_win_icon#size=128 for trophy image
            trophy1 = transform.scale(trophy, (200,250))
            screen.blit(trophy1,(self.width/2-100,self.height/2-125))
            can = image.load(self.characters[self.choice][5])
            can1 = transform.scale(can,(40,80))
            screen.blit(can1,(self.width/2-20,self.height/2-205))
            fonty = font.SysFont("Comic Sans",40,False,False)
            title = fonty.render(self.name,1, (0,0,0))
            screen.blit(title,(self.width/5*2+3,self.height/2+75))
            if self.egg:
                extra = fonty.render("x marks the spot",1,(0,0,0))
                screen.blit(extra,(self.height/2-100,self.height-50))
        if self.gameMode == "Lose":
            end = image.load("yard.jpg")
            screen.blit(end,(0,0))
            draw.polygon(screen,(150,150,150),((20,0),(self.width-20,0),(self.width-20,self.height/20*3),(20,self.height/20*3)),0)
            fonty = font.SysFont("Comic Sans",40,True,False)
            title = fonty.render("You have joined the graveyard",1, (0,0,0))
            second = fonty.render("of unliked Sodas",1,(0,0,0))
            screen.blit(title,(20,self.height/40))
            screen.blit(second,(self.width/2-118,self.height/20*1.75))
        if self.gameMode == "Trophy":
            person = "rink7up.jpg"
            if self.choice == 0:
                person = "drinkaw.png"
            if self.choice == 1:
                person = "drinkpepsi.jpg"
            if self.choice == 2:
                person = "rink7up.jpg"
            #https://www.youtube.com/watch?v=F_VF_Wr2TDE for person drinking pepsi
            #http://interestingthings.info/food-and-beverages/mood-stabilizing-drugs-in-7up.html for person drinking 7up
            #https://www.youtube.com/watch?v=WUhjwYYfbqo for person drinking A&W
            im = image.load(person)
            im = transform.scale(im,(self.width, self.height))
            screen.blit(im,(0,0))
            


Game(500,500).run()