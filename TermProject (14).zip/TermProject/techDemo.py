from pygame import *
from PyGameGame import PygameGame
import math
import random
from Characters import Character
from Characters import Enemy
from Start import StartScreen
from Start import Selection
from Start import EndLevel

# from Characters import Enemy
#PygameGame framework created by Lukas Peraza
class Bullet(sprite.Sprite):
    #defines a bullet
    def __init__(self, x, y, angle, color):
        self.image = image.load(color)
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.angle = angle
        self.rect.x = x
        self.rect.y = y
        self.velocity = 11
        sprite.Sprite.__init__(self)
        
    def move(self):
        self.rect.x += math.cos(math.radians(self.angle))*self.velocity
        self.rect.y += math.sin(math.radians(self.angle))*self.velocity
    
    def check(self, width, height):
        #returns True if bullet off the screen
        if self.rect.x + 10 > width or self.rect.x - 10 < 0 or self.rect.y - 10 < 0 or self.rect.y > height:
            return True
        return False
    
class Flag(sprite.Sprite):
    def __init__(self,x,y):
        self.image = image.load("flag.png")
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        sprite.Sprite.__init__(self)

    def draw(self, screen, scrollX, scrollY, width,height):
        self.rect.x = scrollX
        self.rect.y = scrollY
        print(self.rect.x,self.rect.y, "ugly")
            
class DirectionArrow(sprite.Sprite):
    #shows direction that character faces
    def __init__(self, distance, x, y):
        self.distance = distance
        self.image = image.load("arrow.jpg")
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.angle = 0
        self.distance = 10
        sprite.Sprite.__init__(self)

    def move(self, keyCode):
        if keyCode == 113:
            self.angle -= self.distance
            self.rect.x += math.cos(math.radians(self.angle))*self.distance
            self.rect.y += math.sin(math.radians(self.angle))*self.distance
        if keyCode == 101:
            self.angle += self.distance
            self.rect.x += math.cos(math.radians(self.angle))*self.distance
            self.rect.y += math.sin(math.radians(self.angle))*self.distance
        #move char and rotate the direction it faces
        if keyCode == 100:
            self.angle = 0
        if keyCode == 97:
            self.angle = 180
        if keyCode == 119:
            self.angle = 270
        if keyCode == 115:
            self.angle = 90
        #quick select a direction
        self.rect.x += math.cos(math.radians(self.angle))*self.distance
        self.rect.y += math.sin(math.radians(self.angle))*self.distance
        

class Game(PygameGame):
    def init(self):
        self.bigHeight = self.width*2
        self.bigWidth = self.height*2
        self.scrollX = self.bigWidth/2-self.width/2
        self.scrollY = self.bigHeight/2-self.height/2
        self.gameMode = "End"
        self.choice = 1
        #character selection
        self.characters = [("A&W.png", "orangeBolt.png", "hero.png", "axolotl.jpg", (153,76,0)),("Pepsiman.png", "blueBolt.png","axolotl.jpg", "hero.png", (0,0,255)), ("Spot.png", "redBolt.png","axolotl.jpg", "hero.png", (244, 98, 65))]
        self.char = Character(10, 1, 10, self.characters[self.choice][0],self.width/2,self.height/2)
        #init character and direction arrow
        self.arrow = DirectionArrow(10, self.char.rect.x, self.char.rect.y)
        #position of direction arrow
        self.canGroup1 = sprite.Group()
        self.canGroup2 = sprite.Group()
        #all the enemy cans
        self.charGroup = sprite.Group()
        self.bulletGroup = sprite.Group()
        self.arrowGroup = sprite.Group(self.arrow)
        #creates sprite groups
        self.timer = 0
        #saves time
        self.flagX1 = random.randint(0,self.bigWidth/2)
        self.flagY1 = random.randint(0,self.bigHeight)
        self.flagX2 = random.randint(self.bigWidth/2, self.bigWidth)
        self.flagY2 = random.randint(0,self.bigHeight)
        #sets both flag positions
        self.flag1 = Flag(self.flagX1-self.scrollX,self.flagY1-self.scrollY)
        self.flag2 = Flag(self.flagX2-self.scrollX,self.flagY2-self.scrollY)
        self.flagGroup = sprite.Group(self.flag1, self.flag2)

    def keyPressed(self, keyCode, modifier):
        print(self.scrollX,self.scrollY)
        if self.gameMode == "Start":
            if keyCode == 112:
                self.gameMode = "Select"
        if self.gameMode == "End":
            if keyCode == 304:
                self.gameMode = "Play"
                init()
        if self.gameMode == "Play":
            self.arrow.move(keyCode)
            if keyCode == 275:
                self.scrollX += (10)
            if keyCode == 276:
                self.scrollX += (-10)
            if keyCode == 273:
                self.scrollY += (-10)
            if keyCode == 274:
                self.scrollY += (10)
            #move char
            if keyCode == 32:
                self.bulletGroup.add(Bullet(self.char.rect.x+50,self.char.rect.y+50,self.arrow.angle, self.characters[self.choice][1]))
                
    def mousePressed(self, x, y):
        print(x,y)
        print(int(self.width/3*2+20),int(self.width/3*2+150))
        if self.gameMode == "Select":
            if y in range(int(self.height/3-40), int(self.height/3+60)):
                if x in range(20,150):
                    self.choice = 1
                    self.gameMode = "Play"
                if x in range(int(self.width/3+20),int(self.width/3+150)):
                    self.choice = 0
                    self.gameMode = "Play"
                if x in range(int(self.width/3*2+20),int(self.width/3*2+150)):
                    self.choice = 2
                    self.gameMode = "Play"
                self.char = Character(10, 1, 10, self.characters[self.choice][0],self.width/2,self.height/2)
                self.charGroup.add(self.char)
        
    def timerFired(self, dt):
        if self.gameMode == "Play":
            self.timer += 1
            # print(self.scrollX,self.scrollY)
            # print(250,-190)
            # if self.scrollX == 250:
            #     if self.scrollY == -190:
            #         self.gameMode == "End"
            if self.timer %5 == 0:
                for bullet in self.bulletGroup:
                    bullet.move()
                    # if bullet.check(self.width, self.height):
                    #     self.bulletGroup.remove(bullet)
                        #deletes bullet if off the screen
            # if self.timer % 100 == 0:
            #     print(self.characters[1][3])
            #     self.canGroup1.add(Enemy(2,1,self.characters[1][3], self.width, self.height))
            #     self.canGroup2.add(Enemy(2,1,self.characters[1][3], self.width, self.height))
            #     for can in self.canGroup1:
            #         if can.check(self.width, self.height):
            #             self.canGroup1.remove(can)
            #     for can in self.canGroup2:
            #         if can.check(self.width, self.height):
            #             self.canGroup2.remove(can)
            #             #deletes can

    def redrawAll(self, screen):
        if self.gameMode == "Start":
            StartScreen(self.width, self.height).draw(screen)
        if self.gameMode == "Select":
            Selection(self.width,self.height).draw(screen)
        if self.gameMode == "End":
            EndLevel(self.width, self.height).draw(screen,self.characters[self.choice][0])
        if self.gameMode == "Play":
            draw.polygon(screen, (0,0,0), ((0-self.scrollX,0-self.scrollY),(self.bigWidth-self.scrollX,0-self.scrollY),(self.bigWidth-self.scrollX,self.bigHeight-self.scrollY),(0-self.scrollX,self.bigHeight-self.scrollY)),5)
            if self.choice == 0:
                color1 = 1
                color2 = 2
            if self.choice == 1:
                color1 = 2
                color2 = 0
            if self.choice == 2:
                color1 = 0
                color2 = 1
            draw.polygon(screen, self.characters[color1][4], ((0-self.scrollX,0-self.scrollY),((self.bigWidth/2)-self.scrollX,0-self.scrollY),((self.bigWidth/2)-self.scrollX,self.bigHeight-self.scrollY),(0-self.scrollX,self.bigHeight-self.scrollY)),0)
            draw.polygon(screen, self.characters[color2][4], (((self.bigWidth/2)-self.scrollX,0-self.scrollY),((self.bigWidth)-self.scrollX,0-self.scrollY),((self.bigWidth)-self.scrollX,self.bigHeight-self.scrollY),(self.bigWidth/2-self.scrollX,self.bigHeight-self.scrollY)),0)
            #draw board
            # self.flag1.draw(screen,self.scrollX,self.scrollY, self.bigWidth,self.bigHeight)
            # self.flag2.draw(screen,self.scrollX,self.scrollY, self.bigWidth,self.bigHeight)
            Flag(self.flagX1,self.flagY1).draw(screen,self.scrollX,self.scrollY, self.bigWidth,self.bigHeight)
            Flag(self.flagX2,self.flagY2).draw(screen,self.scrollX,self.scrollY, self.bigWidth,self.bigHeight)
            # self.flagGroup.draw(screen)
            #draw final flags
            self.charGroup.draw(screen)
            # self.arrowGroup.draw(screen)
            if len(self.bulletGroup) > 0:
                self.bulletGroup.draw(screen)
            if len(self.canGroup1) > 0 and len(self.canGroup2) > 0:
                self.canGroup1.draw(screen)
                self.canGroup2.draw(screen)
            #draws every bullet and can

Game(500,500).run()