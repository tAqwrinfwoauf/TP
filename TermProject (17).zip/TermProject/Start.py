from pygame import *
#has the game screens in beginning and end
class StartScreen(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.spacing = 20
        
    def draw(self, screen):
        draw.polygon(screen, (255,0,0), ((0,0),(0,self.height/3),(self.width/3,0)), 0)
        draw.polygon(screen, (255,153,51), ((self.width/3,0),(self.width/3*2,0),(0,self.height/3*2),(0,self.height/3)),0)
        draw.polygon(screen, (0,0,255), ((self.width/3*2,0),(self.width,0),(0,self.height),(0,self.height/3*2)),0)
        draw.polygon(screen, (255,0,0),((self.width,0),(self.width, self.height/3),(self.width/3,self.height), (0,self.height)),0)
        draw.polygon(screen, (255,153,51),((self.width, self.height/3), (self.width,self.height/3*2),(self.width/3*2,self.height),(self.width/3,self.height)),0)
        draw.polygon(screen,(0,0,255),((self.width,self.height/3*2),(self.width,self.height),(self.width/3*2, self.height)),0)
        #the background
        myFont = font.SysFont("Comic Sans",60,True, False)
        line1 = myFont.render("The Great", 1, (0,0,0))
        line2 = myFont.render("Soda Wars", 1, (0,0,0))
        myFont2 = font.SysFont("Comic Sans",30,False,True)
        line3 = myFont2.render("press 'p' to play",1, (0,0,0))
        screen.blit(line1, (self.width/3-self.spacing,self.height/3))
        screen.blit(line2, (self.width/3-self.spacing-10,self.height/3+self.spacing*2))
        screen.blit(line3, (self.width/3, self.height*(3/4)))
        #text
        pepsi = image.load("PepsiCan.png")
        screen.blit(pepsi, (20,250))
        aw = image.load("A&WCan.png")
        screen.blit(aw, (360,250))
        saveImage= image.load("7upCan.png")
        up = saveImage
        up = transform.rotate(up, 90)
        screen.blit(up, (150,20))
        #the cans
        
class Selection(object):
    def __init__(self,width,height):
        self.width = width
        self.height = height
    
    def draw(self,screen):
        myFont = font.SysFont("Comic Sans",30,True, False)
        title = myFont.render("Choose Your Character", 1,(0,0,0))
        screen.blit(title, (self.width/3-(2*2*10), 40))
        #text
        draw.polygon(screen, (0,0,0), ((10,100),(self.width/3-10,100),(self.width/3-10,300),(10,300)),3)
        draw.polygon(screen, (0,0,0),((self.width/3+10,100),(self.width/3*2-10,100),(self.width/3*2-10,300),(self.width/3+10,300)),3)
        draw.polygon(screen, (0,0,0),((self.width/3*2+10,100),(self.width-10,100),(self.width-10,300),(self.width/3*2+10,300)),3)
        #shapes
        pepsi = image.load("PepsiMan.png")
        pepsi = transform.scale(pepsi,(130,130))
        screen.blit(pepsi, (20,self.height/3-40))
        aw = image.load("A&W.png")
        aw = transform.scale(aw,(130,130))
        screen.blit(aw, (self.width/3+20,self.height/3-40))
        up = image.load("Spot.png")
        up = transform.scale(up,(130,130))
        screen.blit(up,(self.width/3*2+20,self.height/3-40))
        #characters
        myFont = font.SysFont("Comic Sans",30,True, False)
        name1 = myFont.render("Pepsi Man",1,(0,0,0))
        name2 = myFont.render("Rooty",1,(0,0,0))
        name3 = myFont.render("Cool Spot",1,(0,0,0))
        screen.blit(name1,(30,260))
        screen.blit(name2,(220,260))
        screen.blit(name3,(360,260))
        #character names
        a = image.load("A&WCan.png")
        a = transform.scale(a,(100,200))
        p = image.load("PepsiCan.png")
        p = transform.scale(p,(100,200))
        u = image.load("7UpCan.png")
        u = transform.scale(u,(100,200))
        screen.blit(p,(30,300))
        screen.blit(a,(200,300))
        screen.blit(u,(365,300))
        
class EndLevel(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def draw(self, screen, character):
        im = image.load(character)
        im = transform.scale(im, (130,130))
        screen.blit(im, (self.width/2-50, self.height/3*2))
        #character
        myFont = font.SysFont("Comic Sans",30, True,False)
        caption = myFont.render("You captured all the fanbases!!",1,(0,0,0))
        screen.blit(caption, (self.width/6, self.height/3))
        next = myFont.render("Press 'shift' to proceed to next level",1,(0,0,0))
        screen.blit(next, (self.width/10, self.height/3+40))
