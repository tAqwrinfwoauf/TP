from pygame import *
from PyGameGame import PygameGame
import math
import random
from Characters import Character
from Characters import Enemy
from Start import StartScreen
from Start import Selection
from Start import EndLevel
import string

# from Characters import Enemy
#PygameGame framework created by Lukas Peraza
#https://gamebanana.com/requests/3908 for the pepsiman sprite
#http://coolspot.wikia.com/wiki/Spot_(Character) for cool spot image
#https://www.pinterest.com/pin/312366924137428328/ for rooty image
#http://alexinthestudio.blogspot.com/2016/03/summative-one-unity-prototype.html for flag image
#http://icons.mysitemyway.com/legacy-icon/004035-grunge-brushed-metal-pewter-icon-arrows-arrowhead-solid-left/ for arrow image
#https://www.vectorstock.com/royalty-free-vector/fire-sprite-sheet-cartoon-flame-game-vector-15143660 for fireballs
#https://www.pinterest.com/pin/369787819385381471/ for blue and red fireballs
#http://bbqpontoon.com/product/pepsi-can for pepsi can image
#https://www.walmart.com/ip/A-W-Root-Beer-12-fl-oz-12-pack/10448431 for A&W can image
#https://www.7up.com/en for 7up can image
#https://twitter.com/heart for heart image
#https://www.iconfinder.com/icons/257805/achievement_award_best_gold_prize_trophy_win_icon#size=128 for trophy image

class Bullet(sprite.Sprite):
    #defines a bullet
    def __init__(self, x, y, angle, color):
        self.image = image.load(color)
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.angle = angle
        self.rect.x = x
        self.rect.y = y
        self.velocity = 11
        sprite.Sprite.__init__(self)
        
    def move(self):
        self.rect.x += math.cos(math.radians(self.angle))*self.velocity
        self.rect.y += math.sin(math.radians(self.angle))*self.velocity
    
    def check(self, width, height):
        #returns True if bullet off the screen
        if self.rect.x + 10 > width or self.rect.x - 10 < 0 or self.rect.y - 10 < 0 or self.rect.y > height:
            return True
        return False
    
class Flag(sprite.Sprite):
    def __init__(self,x,y):
        self.image = image.load("flag.png")
        self.image = transform.scale(self.image,(60,60))
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        sprite.Sprite.__init__(self)

    def draw(self, screen, scrollX, scrollY):
        self.rect.x = self.x - scrollX
        self.rect.y = self.y - scrollY
        screen.blit(self.image,(self.rect.x, self.rect.y))

class DirectionArrow(sprite.Sprite):
    #shows direction that character faces
    def __init__(self, distance, x, y):
        self.distance = distance
        self.image = image.load("arrow.jpg")
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.angle = 0
        self.distance = 10
        sprite.Sprite.__init__(self)

    def move(self, keyCode):
        if keyCode == 113:
            self.angle -= self.distance
            self.rect.x += math.cos(math.radians(self.angle))*self.distance
            self.rect.y += math.sin(math.radians(self.angle))*self.distance
        if keyCode == 101:
            self.angle += self.distance
            self.rect.x += math.cos(math.radians(self.angle))*self.distance
            self.rect.y += math.sin(math.radians(self.angle))*self.distance
        #move char and rotate the direction it faces
        if keyCode == 100:
            self.angle = 0
        if keyCode == 97:
            self.angle = 180
        if keyCode == 119:
            self.angle = 270
        if keyCode == 115:
            self.angle = 90
        #quick select a direction
        self.rect.x += math.cos(math.radians(self.angle))*self.distance
        self.rect.y += math.sin(math.radians(self.angle))*self.distance
        

class Game(PygameGame):
    def init(self):
        self.bigHeight = self.width*2
        self.bigWidth = self.height*2
        self.scrollX = self.bigWidth/2-self.width/2
        self.scrollY = self.bigHeight/2-self.height/2
        self.gameMode = "Start"
        self.choice = 1
        #character selection
        self.characters = [("A&W.png", "orangeBolt.png", "pepsiCan.png", "7upCan.png", (153,76,0), "A&WCan.png"),("Pepsiman.png", "blueBolt.png", "7upCan.png", "A&WCan.png", (0,0,255),"PepsiCan.png"), ("Spot.png", "redBolt.png", "A&WCan.png","pepsiCan.png", (244,98,65),"7upCan.png")]
        self.char = Character(10, 1, 10, self.characters[self.choice][0],self.width/2,self.height/2)
        #init character and direction arrow
        self.arrow = DirectionArrow(10, self.char.rect.x, self.char.rect.y)
        #position of direction arrow
        self.canGroup1 = sprite.Group()
        self.canGroup2 = sprite.Group()
        #all the enemy cans
        self.charGroup = sprite.Group()
        self.bulletGroup = sprite.Group()
        self.arrowGroup = sprite.Group(self.arrow)
        #creates sprite groups
        self.timer = 0
        #saves time
        self.flagFind = 0
        #number of flags you found
        self.flagX1 = random.randint(0,self.bigWidth/2)
        self.flagY1 = random.randint(0,self.bigHeight)
        self.flagX2 = random.randint(self.bigWidth/2, self.bigWidth)
        self.flagY2 = random.randint(0,self.bigHeight)
        #sets both flag positions
        self.flag1 = Flag(self.flagX1,self.flagY1)
        self.flag2 = Flag(self.flagX2, self.flagY2)
        self.flagGroup = (self.flag1,self.flag2)
        self.flag1found = False
        self.flag2found = False
        #flag locations and drawings
        self.level = 1
        #level number
        self.name = ""
        #name of player after win
        
    def keyPressed(self, keyCode, modifier):
        if self.gameMode == "Start":
            if keyCode == 112:
                self.gameMode = "Select"
        if self.gameMode == "End":
            if keyCode == 304:
                self.gameMode = "Play"
                self.char = Character(10+(self.level*1),1+(self.level%2*1),10,self.characters[self.choice][0],self.width/2,self.height/2)
                self.scrollX = self.bigWidth/2-self.width/2
                self.scrollY = self.bigHeight/2-self.height/2
                self.flagX1 = random.randint(0,self.bigWidth/2)
                self.flagY1 = random.randint(0,self.bigHeight)
                self.flagX2 = random.randint(self.bigWidth/2, self.bigWidth)
                self.flagY2 = random.randint(0,self.bigHeight)
                #sets both flag positions
                self.flag1 = Flag(self.flagX1,self.flagY1)
                self.flag2 = Flag(self.flagX2, self.flagY2)
                self.flagGroup = (self.flag1,self.flag2)
                self.flagFind = 0
                self.flag1found = False
                self.flag2found = False
                sprite.Group.empty(self.canGroup1)
                sprite.Group.empty(self.canGroup2)
                sprite.Group.empty(self.bulletGroup)
        if self.gameMode == "Play":
            self.arrow.move(keyCode)
            if keyCode == 275:
                if self.scrollX - 10 > self.bigWidth:
                    self.scrollX = self.scrollX
                self.scrollX += (10)
            if keyCode == 276:
                if self.scrollX - 10 < 0:
                    self.scrollX = self.scrollX
                self.scrollX += (-10)
            if keyCode == 273:
                if self.scrollY - 10 > 0:
                    self.scrollY = self.scrollY
                self.scrollY += (-10)
            if keyCode == 274:
                if self.scrollY - 10 > self.bigHeight:
                    self.scrollY = self.scrollY
                self.scrollY += (10)
            #move char
            if keyCode == 32:
                self.bulletGroup.add(Bullet(self.char.rect.x+50,self.char.rect.y+50,self.arrow.angle, self.characters[self.choice][1]))
        if self.gameMode == "Final":
            caps = False
            print(keyCode)
            if len(self.name) < 4:
                if chr(keyCode) in string.ascii_letters or keyCode == 32:
                        self.name += chr(keyCode)
            if keyCode == 8:
                self.name = self.name[:len(self.name)-1]
            if keyCode == 304:
                self.gameMode = "Win"
                
    def mousePressed(self, x, y):
        if self.gameMode == "Select":
            if y in range(int(self.height/3-40), int(self.height/3+60)):
                if x in range(20,150):
                    self.choice = 1
                    self.gameMode = "Play"
                if x in range(int(self.width/3+20),int(self.width/3+150)):
                    self.choice = 0
                    self.gameMode = "Play"
                if x in range(int(self.width/3*2+20),int(self.width/3*2+150)):
                    self.choice = 2
                    self.gameMode = "Play"
                self.char = Character(10, 1, 10, self.characters[self.choice][0],self.width/2,self.height/2)
                self.charGroup.add(self.char)
        
    def timerFired(self, dt):
        if self.gameMode == "Play":
            print(self.flagFind)
            print(self.flag1.rect.x - self.char.rect.x, self.flag1.rect.y-self.char.rect.y, "flag1")
            print(self.flag2.rect.x - self.char.rect.x, self.flag2.rect.y -self.char.rect.y, "flag2")
            if self.char.health == 0:
                self.gameMode = "Lose"
            self.timer += 1
            if self.timer %2 == 0:
                for bullet in self.bulletGroup:
                    bullet.move()
            if self.timer % 40 == 0:
                print(self.characters[1][3])
                self.canGroup1.add(Enemy(2,1*self.level,self.characters[self.choice][2], random.randint(0,self.bigWidth/2), random.randint(0,self.bigHeight)))
                self.canGroup2.add(Enemy(2,1*self.level,self.characters[self.choice][3], random.randint(self.bigWidth/2,self.bigWidth), random.randint(0,self.bigHeight)))
            if abs(self.flag1.rect.x -self.char.rect.x) <= 60 and abs(self.flag1.rect.y - self.char.rect.y) <= 60 and not self.flag1found:
                for obj in self.canGroup1:
                    obj.can = self.characters[self.choice][5]
                self.flag1found = True
                self.flagFind += 1
                print("bawh")
            if abs(self.flag2.rect.x - self.char.rect.x) <= 60 and abs(self.flag2.rect.y -self.char.rect.y) <= 60 and not self.flag2found:
                for obj in self.canGroup2:
                    obj.can = self.characters[self.choice][5]
                self.flag2found = True
                self.flagFind += 1
            if self.flagFind == 2:
                self.level += 1
                self.gameMode = "End"
            if self.level == 3:
                self.gameMode = "Final"
            if self.timer%5 == 0:
                for can in self.canGroup1:
                    can.move(self.char.rect.x, self.char.rect.y)
                for can in self.canGroup2:
                    can.move(self.char.rect.x, self.char.rect.y)
            for bullet in self.bulletGroup:
                if sprite.spritecollide(bullet, self.canGroup1, True):
                    self.bulletGroup.remove(bullet)
                if sprite.spritecollide(bullet, self.canGroup2, True):
                    self.bulletGroup.remove(bullet)
            if sprite.spritecollide(self.char,self.canGroup1, True) and self.flag1found == False:
                self.char.health -= 1*self.level
            if sprite.spritecollide(self.char,self.canGroup2,True) and self.flag2found == False:
                self.char.health -= 1*self.level


    def redrawAll(self, screen):
        if self.gameMode == "Start":
            StartScreen(self.width, self.height).draw(screen)
            
        if self.gameMode == "Select":
            Selection(self.width,self.height).draw(screen)
            
        if self.gameMode == "End":
            EndLevel(self.width, self.height).draw(screen,self.characters[self.choice][0])
            
        if self.gameMode == "Play":
            draw.polygon(screen, (0,0,0), ((0-self.scrollX,0-self.scrollY),(self.bigWidth-self.scrollX,0-self.scrollY),(self.bigWidth-self.scrollX,self.bigHeight-self.scrollY),(0-self.scrollX,self.bigHeight-self.scrollY)),5)
            if self.choice == 0:
                color1 = 1
                color2 = 2
            if self.choice == 1:
                color1 = 2
                color2 = 0
            if self.choice == 2:
                color1 = 0
                color2 = 1
            draw.polygon(screen, self.characters[color1][4], ((0-self.scrollX,0-self.scrollY),((self.bigWidth/2)-self.scrollX,0-self.scrollY),((self.bigWidth/2)-self.scrollX,self.bigHeight-self.scrollY),(0-self.scrollX,self.bigHeight-self.scrollY)),0)
            draw.polygon(screen, self.characters[color2][4], (((self.bigWidth/2)-self.scrollX,0-self.scrollY),((self.bigWidth)-self.scrollX,0-self.scrollY),((self.bigWidth)-self.scrollX,self.bigHeight-self.scrollY),(self.bigWidth/2-self.scrollX,self.bigHeight-self.scrollY)),0)
            #draw board
            self.flag1.draw(screen,self.scrollX, self.scrollY)
            self.flag2.draw(screen,self.scrollX, self.scrollY)
            #draw final flags
            self.charGroup.draw(screen)
            # self.arrowGroup.draw(screen)
            for can in self.canGroup1:
                can.change(self.scrollX, self.scrollY)
            for can in self.canGroup2:
                can.change(self.scrollX, self.scrollY)
            if len(self.bulletGroup) > 0:
                self.bulletGroup.draw(screen)
            if len(self.canGroup1) > 0 and len(self.canGroup2) > 0:
                self.canGroup1.draw(screen)
                self.canGroup2.draw(screen)
            #draws every bullet and can
            for i in range(1,self.char.health+1):
                heart = image.load("heart.png")
                heart = transform.scale(heart, (20,20))
                screen.blit(heart, (20*i,20))
        #playing the game
        if self.gameMode == "Final":
            fonty = font.SysFont("Comic Sans",40,False,False)
            title = fonty.render("Enter your name",1, (0,0,0))
            screen.blit(title,(self.width/3-30,self.height/3+30))
            middle = fonty.render("To claim the soda industry",1,(0,0,0))
            screen.blit(middle, (self.width/4-50, self.height/3*2))
            bottom = fonty.render("Press shift",1,(0,0,0))
            screen.blit(bottom, (self.width/3,self.height/4*3))
            draw.polygon(screen, (200,200,200), ((self.width/2-120,self.height/2-15),(self.width/2 + 120, self.height/2-15),(self.width/2+120, self.height/2+15),(self.width/2-120, self.height/2+15),5))
            myFont = font.SysFont("Comic Sans",35,True, False)
            name = myFont.render(self.name, 1, (0,0,0))
            screen.blit(name, (self.width/2-105,self.height/2-15))
        #put your name
        if self.gameMode == "Win":
            trophy =  image.load("trophy.png")
            trophy1 = transform.scale(trophy, (200,250))
            screen.blit(trophy1,(self.width/2-100,self.height/2-125))
            can = image.load(self.characters[self.choice][5])
            can1 = transform.scale(can,(40,80))
            screen.blit(can1,(self.width/2-20,self.height/2-205))
            fonty = font.SysFont("Comic Sans",40,False,False)
            title = fonty.render(self.name,1, (0,0,0))
            screen.blit(title,(self.width/5*2+3,self.height/2+75))
        if self.gameMode == "Lose":
            end = image.load("yard.jpg")
            screen.blit(end,(0,0))
            draw.polygon(screen,(150,150,150),((20,0),(self.width-20,0),(self.width-20,self.height/20*3),(20,self.height/20*3)),0)
            fonty = font.SysFont("Comic Sans",40,True,False)
            title = fonty.render("You have joined the graveyard",1, (0,0,0))
            second = fonty.render("of Sodas",1,(0,0,0))
            screen.blit(title,(20,self.height/20))
            screen.blit(second,(self.width/2-70,self.height/20*2))
            


Game(500,500).run()