from pygame import *
import math
import random
class Character(sprite.Sprite):
    #the character that you choose
    def __init__(self, health, attack, speed, character, width, height):
        self.health = health
        self.attack = attack
        self.speed = speed
        self.character = character
        #char attack and health and character
        self.image = image.load(self.character)
        self.image = transform.scale(self.image,(100,100))
        self.rect = self.image.get_rect()
        self.rect.x = width - 50
        self.rect.y = height
        self.x = self.rect.x
        self.y = self.rect.y
        #position and creation of char
        self.currLvl = 1
        #level of character
        sprite.Sprite.__init__(self)
    
    def move(self, x, y, width, height):
        self.rect.x = x
        self.rect.y = y

class Enemy(sprite.Sprite):
    def __init__(self,health,attack,can, x, y):
        self.health = health
        self.attack = attack
        self.can = can
        self.image = image.load(self.can)
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        sprite.Sprite.__init__(self)
    
    def attack(self,shoe):
        return (self.attack)

    def change(self, scrollX, scrollY):
        self.rect.x = self.x - scrollX
        self.rect.y = self.y - scrollY
        
    def move(self, charX, charY):
        if charX < self.rect.x:
            self.x -= 5
        if charX > self.rect.x:
            self.x += 5
        if charY > self.rect.y:
            self.y += 5
        if charY < self.rect.y:
            self.y -= 5
            
class Shooter(sprite.Sprite):
    def __init__(self,health,attack,can, x, y):
        self.health = health
        self.attack = attack
        self.can = can
        self.image = image.load(self.can)
        self.image = transform.scale(self.image,(20,20))
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        sprite.Sprite.__init__(self)
        
    def change(self, scrollX, scrollY):
        self.rect.x = self.x - scrollX
        self.rect.y = self.y - scrollY
        
    def move(self, charX, charY):
        if charX < self.rect.x:
            self.x -= 1
        if charX > self.rect.x:
            self.x += 1
        if charY > self.rect.y:
            self.y += 1
        if charY < self.rect.y:
            self.y -= 1